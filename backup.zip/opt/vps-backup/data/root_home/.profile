# ~/.profile: executed by Bourne-compatible login shells.

if [ "$BASH" ]; then
  if [ -f ~/.bashrc ]; then
    . ~/.bashrc
  fi
fi

mesg n 2> /dev/null || true
. "/etc/skel/.cargo/env"

# Created by `pipx` on 2025-11-26 17:27:31
export PATH="$PATH:/opt/pipx_bin"
