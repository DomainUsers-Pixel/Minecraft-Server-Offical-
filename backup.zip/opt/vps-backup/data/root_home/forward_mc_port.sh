#!/bin/bash

# ===============================================
# USER-DEFINED VARIABLES (CONFIRM THESE)
# ===============================================
# The private IP assigned to the OpenVPN client running the Minecraft server
CLIENT_VPN_IP="10.8.0.2"
# The port the Minecraft server uses
MC_PORT="25565"
# The protocol(s) for the port
PROTOCOL="tcp udp"
# The OpenVPN internal network subnet
VPN_SUBNET="10.8.0.0/24"


# ===============================================
# AUTOMATICALLY DETERMINE WAN INTERFACE
# ===============================================
# Finds the network interface used for the default route (the public-facing one)
WAN_IF=$(ip route show default | awk '{print $5}' | head -n 1)

if [ -z "$WAN_IF" ]; then
    echo "ERROR: Could not automatically determine the WAN interface. Assuming 'eth0'."
    WAN_IF="eth0"
else
    echo "Detected WAN Interface: ${WAN_IF}"
fi
echo "Client VPN IP: ${CLIENT_VPN_IP}"
echo "Minecraft Port: ${MC_PORT}"
echo "----------------------------------------"
echo "Applying iptables rules..."

# Check if rules already exist before adding them (to prevent duplicates)
if sudo iptables -t nat -C PREROUTING -i "$WAN_IF" -p tcp --dport "$MC_PORT" -j DNAT --to-destination "$CLIENT_VPN_IP:$MC_PORT" 2>/dev/null; then
    echo "Port forwarding rules seem to be installed already. Skipping rule application."
else
    # 1. PREROUTING (Destination NAT - DNAT): Redirect public traffic to the client's VPN IP
    for proto in $PROTOCOL; do
        echo " - Adding DNAT rule for $proto..."
        sudo iptables -t nat -A PREROUTING -i "$WAN_IF" -p "$proto" --dport "$MC_PORT" -j DNAT --to-destination "$CLIENT_VPN_IP:$MC_PORT"
    done

    # 2. POSTROUTING (Source NAT - SNAT/MASQUERADE): Mask the client's return traffic 
    #    so it returns to the internet through the VPS's public IP.
    echo " - Adding MASQUERADE rule for return traffic..."
    sudo iptables -t nat -A POSTROUTING -s "$VPN_SUBNET" -o "$WAN_IF" -j MASQUERADE
    
    # 3. FORWARD Chain: Allow the forwarded traffic to pass
    for proto in $PROTOCOL; do
        echo " - Adding FORWARD rule for $proto..."
        # Allow incoming traffic to the client
        sudo iptables -A FORWARD -i "$WAN_IF" -o tun0 -p "$proto" --dport "$MC_PORT" -d "$CLIENT_VPN_IP" -j ACCEPT
    done
    
    # Accept established and related connections (important for replies)
    sudo iptables -A FORWARD -m state --state RELATED,ESTABLISHED -j ACCEPT
    
    # Allow all traffic from the VPN network (tun0) out to the WAN (eth0/ens3)
    sudo iptables -A FORWARD -i tun0 -o "$WAN_IF" -j ACCEPT

    echo "✅ Port forwarding rules applied successfully."
fi

# 4. Persistence: Save the rules so they survive a reboot
echo "----------------------------------------"
echo "Making rules persistent (saving for reboot)..."

# Use iptables-persistent for Debian/Ubuntu systems
if command -v netfilter-persistent &> /dev/null; then
    sudo netfilter-persistent save
    echo "✅ Rules saved using netfilter-persistent."
elif command -v service &> /dev/null && service iptables status &> /dev/null; then
    # Use service iptables save for CentOS/RHEL systems
    sudo service iptables save
    echo "✅ Rules saved using 'service iptables save'."
else
    echo "⚠️ WARNING: Could not automatically save rules. Install 'iptables-persistent' to save."
    echo "   (e.g., sudo apt update && sudo apt install iptables-persistent)"
fi

echo "----------------------------------------"
echo "Testing: Try connecting to 135.232.201.86:25565 now."
